	// Script to get quiz results, add it to url of search page
	// in the search page, there is another script that takes the url and then
	// selects the filters, and then runs search
	function quizFunction() {
		let baseURL = "GEH_SEARCH.html";

		let passion = $('input[name="group1"]:checked').val();
		let style = $('input[name="group2"]:checked').val();

		let optionURL = baseURL + '?pas=' + passion + '&sty=' + style;
		window.location.href = optionURL;
	}



	//***************** CREATES A NEW USER. ********************
	//Event listener for submitting the sign-up page.
	document.getElementById('signUpPopUp').addEventListener('submit', signUp);

	function signUp(e) {

		e.preventDefault();
		var username = document.getElementById("username").value;
		var password = document.getElementById("password").value;

		//Creates the new user and authenticates in FB. Adds user/email to database too.
		console.log("Hi from submit form");
		firebase.auth().createUserWithEmailAndPassword(username, password).then(function (user) {
			var user = firebase.auth().currentUser;
			console.log("no err");
			firebase.database().ref("users/" + user.uid).update({
				"email": user.email
			});
			window.location.href = "Good-Earth-Hub-LOGGEDIN.html";
		}, function (error) {
			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			console.log(errorCode + " " + errorMessage);
			// ...

		});
	}

	// *************** EXISTING USER LOG IN *****************	
	//Event listener for submitting the sign-up page.
	document.getElementById('logInPopUp').addEventListener('submit', logIn);

	function logIn(e) {
		console.log("Hi from log in2");
		e.preventDefault();
		var user = document.getElementById("user").value;
		var pass = document.getElementById("pass").value;

		var promise = firebase.auth().signInWithEmailAndPassword(user, pass);
		promise.then(function () {
			window.location.href = 'Good-Earth-Hub-LOGGEDIN.html';

			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			// ...
		});
	}


	// *************** EXISTING USER LOG IN *****************	
	//Event listener for submitting the sign-up page.
	document.getElementById('logInPopUp').addEventListener('submit', logIn);

	function logIn(e) {
		console.log("Hi from log in2");
		e.preventDefault();
		var user = document.getElementById("user").value;
		var pass = document.getElementById("pass").value;

		var promise = firebase.auth().signInWithEmailAndPassword(user, pass);
		promise.then(function () {
			window.location.href = 'Good-Earth-Hub-LOGGEDIN.html';

			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			// ...
		});
	}
