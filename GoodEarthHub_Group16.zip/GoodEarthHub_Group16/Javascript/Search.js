


		//JavaScript for the Search Function
		$(document).ready(setPrefs());

		// this is for the quiz results
		function setPrefs() {
			let windowURL = window.location.href;
			let url = new URL(windowURL);
			let sty = url.searchParams.get("sty");
			let pas = url.searchParams.get("pas");

			if (sty) {
				switch (sty) {
					case "Casual":
						$('#casualOption').prop('checked', true);
						break;
					case "Formal":
						$('#formalOption').prop('checked', true);
						break;
				}
			}

			if (pas) {
				switch (pas) {
					case "Vegan":
						$('#veganOption').prop('checked', true);
						break;
					case "Canadian":
						$('#canadianOption').prop('checked', true);
						break;
				}
			}

		}

		// allows search to happen after pressing enter key
		var input = document.getElementById("searchText");
		input.addEventListener("keyup", function(event) {
			event.preventDefault();
			if (event.keyCode === 13) {
				document.getElementById("searchSubmit").click();
			}
		});

		// data 
		var data;
		var dataArray;
		var currentSearchArray = new Array();

		// takes snapshot of database 
		firebase.database().ref().on("value", function(snapshot) {
			data = snapshot.val();
			console.log(data);
			main();
		}, function(error) {
			console.log("Error: " + error.code);
		});

		// looks through the database for searched words
		function find(arrayIn) {
			rawText = document.getElementById("searchText").value;
			searchText = rawText.trim().toLowerCase();
			console.log(searchText);
			var result = new Array();
			console.log('searching for ' + searchText);

			for (var bob in arrayIn) {
				console.log(arrayIn[bob].name);

				var matches = arrayIn[bob].name.indexOf(searchText) >= 0 ? true : false;
				if (matches) {
					console.log("adding " + arrayIn[bob].name);
					result.push(arrayIn[bob]);
				}
			}
			console.log(result);
			return result;
		}

		// sorting function
		function sort(arrayIn) {
			var result = arrayIn;

			var sortType = $("#sort")[0].value;

			console.log(sortType);

			switch (sortType) {
				case "alpha":
					result.sort(function(a, b) {
						return a.name.localeCompare(b.name);
					});
					break;
				case "lowToHigh":
					result.sort(function(a, b) {
						return a.price - b.price;
					});
					break;
				case "highToLow":
					result.sort(function(a, b) {
						return b.price - a.price;
					});
					break;
			}

			return result;
		}

		// filtering function
		function filter(arrayIn) {
			var result = arrayIn;

			//get checkbox values
			var isVegan = $("#veganOption")[0].checked;
			var isCanadian = $("#canadianOption")[0].checked;
			var isCasual = $("#casualOption")[0].checked;
			var isFormal = $("#formalOption")[0].checked;



			//run filter checks

			if (isVegan) {
				result = result.filter(function(bob) {
					//					console.log(bob);
					return bob.vegan;
				});
			}

			if (isCanadian) {
				result = result.filter(function(bob) {
					return bob.canadian;
				});
			}

			if (isCasual) {
				result = result.filter(function(bob) {
					return bob.casual;
				});
			}

			if (isFormal) {
				result = result.filter(function(bob) {
					return bob.formal;
				});
			}

			console.log(result);
			return result;
		}

		// puts all the sorts and filter results together
		function search(arrayIn) {
			var searchedArray = find(arrayIn);
			var filteredArray = filter(searchedArray);
			var sortedArray = sort(filteredArray);
			console.log(sortedArray);
			$('#resultCards')[0].innerHTML = "";
			currentSearchArray = sortedArray;
			toDisplay(sortedArray);

		}



		// initialization function
		function main() {
			collection = data['Collections']['allClothing'];
			dataArray = Object.keys(collection).map(i => collection[i]);
			console.log("test");
			console.log(dataArray);

			search(dataArray);

		}

		// the above code searches, filters, sorts the firebase items into an array. 
		// The below functions take each item
		// in the array and makes it into html elements 
		function toDisplay(displayArray) {
			for (var tempItem in displayArray) {
				console.log(tempItem);
				generateCard(displayArray[tempItem], tempItem);
			}
		}

		function generateCard(tempItem, itemIndex) {

			let bigButton = $('<button onclick = "generateModal(' + itemIndex + ')"></button>');

			let card = $('<div class = "card" id = "' + tempItem.name + '_card"></div>');
			let name = $('<p class = "quickViewStyle">' + tempItem.name + '</p>');
			let price = $('<p class = "quickViewStyle">' + tempItem.price + '</p>');
			let image = $('<img src = "' + tempItem.imageurl + '" alt = "Quick View">');

			bigButton.append(name, price, image);
			card.append(bigButton);

			$('#resultCards').append(card);

		}

		// Script for making the modal pop up when item is clicked
		function generateModal(item) {

			let modalDivDiv = $('<div class="modalSearch"></div>');
			let modalDiv = $('<div class = "modal100-content"></div>');
			let closeModal = $('<span class = "close" onclick = "removeModal()">&times;</span>');

			let nameModal = $('<p class = "quickViewStyle">' + currentSearchArray[item].name + '</p>');
			let priceModal = $('<p class = "quickViewStyle">' + currentSearchArray[item].price + '</p>');
			let imageModal = $('<p class = "quickViewStyle"><img src = "' + currentSearchArray[item].imageurl + '" alt = "Quick View"></p>');
			let companySite = $('<a href = "' + currentSearchArray[item].company + '" target = "_blank"  class = "quickViewStyle">View on Company Website</a>');

			modalDiv.append(closeModal, nameModal, priceModal, imageModal, companySite);
			modalDivDiv.append(modalDiv);
			$('#resultCards').append(modalDivDiv);

		}


		//		Function to remove the modal
		function removeModal() {
			$('div.modalSearch').remove();
		}


	//***************** CREATES A NEW USER. ********************
	//Event listener for submitting the sign-up page.
	document.getElementById('signUpPopUp').addEventListener('submit', signUp);
	
	function signUp(e) {

       e.preventDefault();
        var username = document.getElementById("username").value;
	    var password = document.getElementById("password").value;
		
		//Creates the new user and authenticates in FB. Adds user/email to database too.
		console.log("Hi from submit form");
	   	firebase.auth().createUserWithEmailAndPassword(username, password).then(function(user) {
		   var user = firebase.auth().currentUser;
		   console.log("no err");
		   firebase.database().ref("users/"+user.uid).update(
			{
				"email":user.email
				});
				window.location.href="Good-Earth-Hub-LOGGEDIN.html";
			}, function(error) {
			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			console.log(errorCode+" "+ errorMessage);
			// ...
	
	});
}

		// *************** EXISTING USER LOG IN *****************	
		//Event listener for submitting the sign-up page.
		document.getElementById('logInPopUp').addEventListener('submit', logIn);		
	
		function logIn(e) {
			console.log("Hi from log in2");
			e.preventDefault();
			 var user = document.getElementById("user").value;
			 var pass = document.getElementById("pass").value;
	
					var promise = firebase.auth().signInWithEmailAndPassword(user, pass);
					promise.then(function() {
						window.location.href='Good-Earth-Hub-LOGGEDIN.html';
	
				// Handle Errors here.
				var errorCode = error.code;
				var errorMessage = error.message;
				// ...
				});
			}


// *************** EXISTING USER LOG IN *****************	
		//Event listener for submitting the sign-up page.
		document.getElementById('logInPopUp').addEventListener('submit', logIn);		
	
		function logIn(e) {
			console.log("Hi from log in2");
			e.preventDefault();
			 var user = document.getElementById("user").value;
			 var pass = document.getElementById("pass").value;
	
					var promise = firebase.auth().signInWithEmailAndPassword(user, pass);
					promise.then(function() {
						window.location.href='Good-Earth-Hub-LOGGEDIN.html';
	
				// Handle Errors here.
				var errorCode = error.code;
				var errorMessage = error.message;
				// ...
				});
			}