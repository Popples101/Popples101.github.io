Good Earth Hub:
Purpose of the website: To provide a database and search engine of ethically-made clothing from various brands and storefronts in one place. Our targeted audience are consumers already interested in living an eco-friendly and socially-conscious lifestyle. 

Our Project folder contains four subfolders:
- CSS (Homepage and search page css)
- HTML(Login/signup pop up, quiz, search, homepage, logged in homepage)
- Image (Images of the clothing and logo)
- Javascript (quiz, search, and authentication)

Disclaimer: Quiz results, search results, and login/sign-up authentication may take longer than other pages to load.

Made by Group 16:
Amy Balfour A00997298
Shinai Sorensen A01059813
Lucy Hu A01006985
Michelle Le A00961622
